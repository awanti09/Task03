package com.example.task3

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {
    @SuppressLint("WrongViewCast")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val logout = findViewById<TextView>(R.id.logout)
        logout.setOnClickListener {
            // Perform logout actions here
            // For example, clear user session, navigate to login screen, etc.

            // Create an Intent to start MainActivity2
            val intent = Intent(this, MainActivity2::class.java)
            startActivity(intent)

            // Finish the current activity (MainActivity) if you want to prevent returning to it
            finish()
        }

    }
}
